<?php $sumsoal=1; $sum=1; foreach ($posttest as $key => $value) {
            if ($value->id_posttest == $id) {
                $sumsoal += $sum;
            }} ?>

<?php 
    if ($kunci->kunci_1 == 'A') {
        $checked_1a = 'checked';
    }else{
        $checked_1a = '';
    }

    if ($kunci->kunci_1 == 'B') {
        $checked_1b = 'checked';
    }else{
        $checked_1b = '';
    }

    if ($kunci->kunci_1 == 'C') {
        $checked_1c = 'checked';
    }else{
        $checked_1c = '';
    }

    if ($kunci->kunci_1 == 'D') {
        $checked_1d = 'checked';
    }else{
        $checked_1d = '';
    }

    if ($kunci->kunci_1 == 'E') {
        $checked_1e = 'checked';
    }else{
        $checked_1e = '';
    }


    if ($kunci->kunci_2 == 'A') {
        $checked_2a = 'checked';
    }else{
        $checked_2a = '';
    }

    if ($kunci->kunci_2 == 'B') {
        $checked_2b = 'checked';
    }else{
        $checked_2b = '';
    }

    if ($kunci->kunci_2 == 'C') {
        $checked_2c = 'checked';
    }else{
        $checked_2c = '';
    }

    if ($kunci->kunci_2 == 'D') {
        $checked_2d = 'checked';
    }else{
        $checked_2d = '';
    }

    if ($kunci->kunci_2 == 'E') {
        $checked_2e = 'checked';
    }else{
        $checked_2e = '';
    }


    if ($kunci->kunci_3 == 'A') {
        $checked_3a = 'checked';
    }else{
        $checked_3a = '';
    }

    if ($kunci->kunci_3 == 'B') {
        $checked_3b = 'checked';
    }else{
        $checked_3b = '';
    }

    if ($kunci->kunci_3 == 'C') {
        $checked_3c = 'checked';
    }else{
        $checked_3c = '';
    }

    if ($kunci->kunci_3 == 'D') {
        $checked_3d = 'checked';
    }else{
        $checked_3d = '';
    }

    if ($kunci->kunci_3 == 'E') {
        $checked_3e = 'checked';
    }else{
        $checked_3e = '';
    }

    if ($kunci->kunci_4 == 'A') {
        $checked_4a = 'checked';
    }else{
        $checked_4a = '';
    }

    if ($kunci->kunci_4 == 'B') {
        $checked_4b = 'checked';
    }else{
        $checked_4b = '';
    }

    if ($kunci->kunci_4 == 'C') {
        $checked_4c = 'checked';
    }else{
        $checked_4c = '';
    }

    if ($kunci->kunci_4 == 'D') {
        $checked_4d = 'checked';
    }else{
        $checked_4d = '';
    }

    if ($kunci->kunci_4 == 'E') {
        $checked_4e = 'checked';
    }else{
        $checked_4e = '';
    }

    if ($kunci->kunci_5 == 'A') {
        $checked_5a = 'checked';
    }else{
        $checked_5a = '';
    }

    if ($kunci->kunci_5 == 'B') {
        $checked_5b = 'checked';
    }else{
        $checked_5b = '';
    }

    if ($kunci->kunci_5 == 'C') {
        $checked_5c = 'checked';
    }else{
        $checked_5c = '';
    }

    if ($kunci->kunci_5 == 'D') {
        $checked_5d = 'checked';
    }else{
        $checked_5d = '';
    }

    if ($kunci->kunci_5 == 'E') {
        $checked_5e = 'checked';
    }else{
        $checked_5e = '';
    }


    if ($kunci->kunci_6 == 'A') {
        $checked_6a = 'checked';
    }else{
        $checked_6a = '';
    }

    if ($kunci->kunci_6 == 'B') {
        $checked_6b = 'checked';
    }else{
        $checked_6b = '';
    }

    if ($kunci->kunci_6 == 'C') {
        $checked_6c = 'checked';
    }else{
        $checked_6c = '';
    }

    if ($kunci->kunci_6 == 'D') {
        $checked_6d = 'checked';
    }else{
        $checked_6d = '';
    }

    if ($kunci->kunci_6 == 'E') {
        $checked_6e = 'checked';
    }else{
        $checked_6e = '';
    }

    if ($kunci->kunci_7 == 'A') {
        $checked_7a = 'checked';
    }else{
        $checked_7a = '';
    }

    if ($kunci->kunci_7 == 'B') {
        $checked_7b = 'checked';
    }else{
        $checked_7b = '';
    }

    if ($kunci->kunci_7 == 'C') {
        $checked_7c = 'checked';
    }else{
        $checked_7c = '';
    }

    if ($kunci->kunci_7 == 'D') {
        $checked_7d = 'checked';
    }else{
        $checked_7d = '';
    }

    if ($kunci->kunci_7 == 'E') {
        $checked_7e = 'checked';
    }else{
        $checked_7e = '';
    }

    if ($kunci->kunci_8 == 'A') {
        $checked_8a = 'checked';
    }else{
        $checked_8a = '';
    }

    if ($kunci->kunci_8 == 'B') {
        $checked_8b = 'checked';
    }else{
        $checked_8b = '';
    }

    if ($kunci->kunci_8 == 'C') {
        $checked_8c = 'checked';
    }else{
        $checked_8c = '';
    }

    if ($kunci->kunci_8 == 'D') {
        $checked_8d = 'checked';
    }else{
        $checked_8d = '';
    }

    if ($kunci->kunci_8 == 'E') {
        $checked_8e = 'checked';
    }else{
        $checked_8e = '';
    }

    if ($kunci->kunci_9 == 'A') {
        $checked_9a = 'checked';
    }else{
        $checked_9a = '';
    }

    if ($kunci->kunci_9 == 'B') {
        $checked_9b = 'checked';
    }else{
        $checked_9b = '';
    }

    if ($kunci->kunci_9 == 'C') {
        $checked_9c = 'checked';
    }else{
        $checked_9c = '';
    }

    if ($kunci->kunci_9 == 'D') {
        $checked_9d = 'checked';
    }else{
        $checked_9d = '';
    }

    if ($kunci->kunci_9 == 'E') {
        $checked_9e = 'checked';
    }else{
        $checked_9e = '';
    }

    if ($kunci->kunci_10 == 'A') {
        $checked_10a = 'checked';
    }else{
        $checked_10a = '';
    }

    if ($kunci->kunci_10 == 'B') {
        $checked_10b = 'checked';
    }else{
        $checked_10b = '';
    }

    if ($kunci->kunci_10 == 'C') {
        $checked_10c = 'checked';
    }else{
        $checked_10c = '';
    }

    if ($kunci->kunci_10 == 'D') {
        $checked_10d = 'checked';
    }else{
        $checked_10d = '';
    }

    if ($kunci->kunci_10 == 'E') {
        $checked_10e = 'checked';
    }else{
        $checked_10e = '';
    }


    if ($kunci->kunci_11 == 'A') {
        $checked_11a = 'checked';
    }else{
        $checked_11a = '';
    }

    if ($kunci->kunci_11 == 'B') {
        $checked_11b = 'checked';
    }else{
        $checked_11b = '';
    }

    if ($kunci->kunci_11 == 'C') {
        $checked_11c = 'checked';
    }else{
        $checked_11c = '';
    }

    if ($kunci->kunci_11 == 'D') {
        $checked_11d = 'checked';
    }else{
        $checked_11d = '';
    }

    if ($kunci->kunci_11 == 'E') {
        $checked_11e = 'checked';
    }else{
        $checked_11e = '';
    }


    if ($kunci->kunci_12 == 'A') {
        $checked_12a = 'checked';
    }else{
        $checked_12a = '';
    }

    if ($kunci->kunci_12 == 'B') {
        $checked_12b = 'checked';
    }else{
        $checked_12b = '';
    }

    if ($kunci->kunci_12 == 'C') {
        $checked_12c = 'checked';
    }else{
        $checked_12c = '';
    }

    if ($kunci->kunci_12 == 'D') {
        $checked_12d = 'checked';
    }else{
        $checked_12d = '';
    }

    if ($kunci->kunci_12 == 'E') {
        $checked_12e = 'checked';
    }else{
        $checked_12e = '';
    }


    if ($kunci->kunci_13 == 'A') {
        $checked_13a = 'checked';
    }else{
        $checked_13a = '';
    }

    if ($kunci->kunci_13 == 'B') {
        $checked_13b = 'checked';
    }else{
        $checked_13b = '';
    }

    if ($kunci->kunci_13 == 'C') {
        $checked_13c = 'checked';
    }else{
        $checked_13c = '';
    }

    if ($kunci->kunci_13 == 'D') {
        $checked_13d = 'checked';
    }else{
        $checked_13d = '';
    }

    if ($kunci->kunci_13 == 'E') {
        $checked_13e = 'checked';
    }else{
        $checked_13e = '';
    }

    if ($kunci->kunci_14 == 'A') {
        $checked_14a = 'checked';
    }else{
        $checked_14a = '';
    }

    if ($kunci->kunci_14 == 'B') {
        $checked_14b = 'checked';
    }else{
        $checked_14b = '';
    }

    if ($kunci->kunci_14 == 'C') {
        $checked_14c = 'checked';
    }else{
        $checked_14c = '';
    }

    if ($kunci->kunci_14 == 'D') {
        $checked_14d = 'checked';
    }else{
        $checked_14d = '';
    }

    if ($kunci->kunci_14 == 'E') {
        $checked_14e = 'checked';
    }else{
        $checked_14e = '';
    }

    if ($kunci->kunci_15 == 'A') {
        $checked_15a = 'checked';
    }else{
        $checked_15a = '';
    }

    if ($kunci->kunci_15 == 'B') {
        $checked_15b = 'checked';
    }else{
        $checked_15b = '';
    }

    if ($kunci->kunci_15 == 'C') {
        $checked_15c = 'checked';
    }else{
        $checked_15c = '';
    }

    if ($kunci->kunci_15 == 'D') {
        $checked_15d = 'checked';
    }else{
        $checked_15d = '';
    }

    if ($kunci->kunci_15 == 'E') {
        $checked_15e = 'checked';
    }else{
        $checked_15e = '';
    }


    if ($kunci->kunci_16 == 'A') {
        $checked_16a = 'checked';
    }else{
        $checked_16a = '';
    }

    if ($kunci->kunci_16 == 'B') {
        $checked_16b = 'checked';
    }else{
        $checked_16b = '';
    }

    if ($kunci->kunci_16 == 'C') {
        $checked_16c = 'checked';
    }else{
        $checked_16c = '';
    }

    if ($kunci->kunci_16 == 'D') {
        $checked_16d = 'checked';
    }else{
        $checked_16d = '';
    }

    if ($kunci->kunci_16 == 'E') {
        $checked_16e = 'checked';
    }else{
        $checked_16e = '';
    }

    if ($kunci->kunci_17 == 'A') {
        $checked_17a = 'checked';
    }else{
        $checked_17a = '';
    }

    if ($kunci->kunci_17 == 'B') {
        $checked_17b = 'checked';
    }else{
        $checked_17b = '';
    }

    if ($kunci->kunci_17 == 'C') {
        $checked_17c = 'checked';
    }else{
        $checked_17c = '';
    }

    if ($kunci->kunci_17 == 'D') {
        $checked_17d = 'checked';
    }else{
        $checked_17d = '';
    }

    if ($kunci->kunci_17 == 'E') {
        $checked_17e = 'checked';
    }else{
        $checked_17e = '';
    }

    if ($kunci->kunci_18 == 'A') {
        $checked_18a = 'checked';
    }else{
        $checked_18a = '';
    }

    if ($kunci->kunci_18 == 'B') {
        $checked_18b = 'checked';
    }else{
        $checked_18b = '';
    }

    if ($kunci->kunci_18 == 'C') {
        $checked_18c = 'checked';
    }else{
        $checked_18c = '';
    }

    if ($kunci->kunci_18 == 'D') {
        $checked_18d = 'checked';
    }else{
        $checked_18d = '';
    }

    if ($kunci->kunci_18 == 'E') {
        $checked_18e = 'checked';
    }else{
        $checked_18e = '';
    }

    if ($kunci->kunci_19 == 'A') {
        $checked_19a = 'checked';
    }else{
        $checked_19a = '';
    }

    if ($kunci->kunci_19 == 'B') {
        $checked_19b = 'checked';
    }else{
        $checked_19b = '';
    }

    if ($kunci->kunci_19 == 'C') {
        $checked_19c = 'checked';
    }else{
        $checked_19c = '';
    }

    if ($kunci->kunci_19 == 'D') {
        $checked_19d = 'checked';
    }else{
        $checked_19d = '';
    }

    if ($kunci->kunci_19 == 'E') {
        $checked_19e = 'checked';
    }else{
        $checked_19e = '';
    }

    if ($kunci->kunci_20 == 'A') {
        $checked_20a = 'checked';
    }else{
        $checked_20a = '';
    }

    if ($kunci->kunci_20 == 'B') {
        $checked_20b = 'checked';
    }else{
        $checked_20b = '';
    }

    if ($kunci->kunci_20 == 'C') {
        $checked_20c = 'checked';
    }else{
        $checked_20c = '';
    }

    if ($kunci->kunci_20 == 'D') {
        $checked_20d = 'checked';
    }else{
        $checked_20d = '';
    }

    if ($kunci->kunci_20 == 'E') {
        $checked_20e = 'checked';
    }else{
        $checked_20e = '';
    }


    if ($kunci->kunci_21 == 'A') {
        $checked_21a = 'checked';
    }else{
        $checked_21a = '';
    }

    if ($kunci->kunci_21 == 'B') {
        $checked_21b = 'checked';
    }else{
        $checked_21b = '';
    }

    if ($kunci->kunci_21 == 'C') {
        $checked_21c = 'checked';
    }else{
        $checked_21c = '';
    }

    if ($kunci->kunci_21 == 'D') {
        $checked_21d = 'checked';
    }else{
        $checked_21d = '';
    }

    if ($kunci->kunci_21 == 'E') {
        $checked_21e = 'checked';
    }else{
        $checked_21e = '';
    }


    if ($kunci->kunci_22 == 'A') {
        $checked_22a = 'checked';
    }else{
        $checked_22a = '';
    }

    if ($kunci->kunci_22 == 'B') {
        $checked_22b = 'checked';
    }else{
        $checked_22b = '';
    }

    if ($kunci->kunci_22 == 'C') {
        $checked_22c = 'checked';
    }else{
        $checked_22c = '';
    }

    if ($kunci->kunci_22 == 'D') {
        $checked_22d = 'checked';
    }else{
        $checked_22d = '';
    }

    if ($kunci->kunci_22 == 'E') {
        $checked_22e = 'checked';
    }else{
        $checked_22e = '';
    }


    if ($kunci->kunci_23 == 'A') {
        $checked_23a = 'checked';
    }else{
        $checked_23a = '';
    }

    if ($kunci->kunci_23 == 'B') {
        $checked_23b = 'checked';
    }else{
        $checked_23b = '';
    }

    if ($kunci->kunci_23 == 'C') {
        $checked_23c = 'checked';
    }else{
        $checked_23c = '';
    }

    if ($kunci->kunci_23 == 'D') {
        $checked_23d = 'checked';
    }else{
        $checked_23d = '';
    }

    if ($kunci->kunci_23 == 'E') {
        $checked_23e = 'checked';
    }else{
        $checked_23e = '';
    }

    if ($kunci->kunci_24 == 'A') {
        $checked_24a = 'checked';
    }else{
        $checked_24a = '';
    }

    if ($kunci->kunci_24 == 'B') {
        $checked_24b = 'checked';
    }else{
        $checked_24b = '';
    }

    if ($kunci->kunci_24 == 'C') {
        $checked_24c = 'checked';
    }else{
        $checked_24c = '';
    }

    if ($kunci->kunci_24 == 'D') {
        $checked_24d = 'checked';
    }else{
        $checked_24d = '';
    }

    if ($kunci->kunci_24 == 'E') {
        $checked_24e = 'checked';
    }else{
        $checked_24e = '';
    }

    if ($kunci->kunci_25 == 'A') {
        $checked_25a = 'checked';
    }else{
        $checked_25a = '';
    }

    if ($kunci->kunci_25 == 'B') {
        $checked_25b = 'checked';
    }else{
        $checked_25b = '';
    }

    if ($kunci->kunci_25 == 'C') {
        $checked_25c = 'checked';
    }else{
        $checked_25c = '';
    }

    if ($kunci->kunci_25 == 'D') {
        $checked_25d = 'checked';
    }else{
        $checked_25d = '';
    }

    if ($kunci->kunci_25 == 'E') {
        $checked_25e = 'checked';
    }else{
        $checked_25e = '';
    }


    if ($kunci->kunci_26 == 'A') {
        $checked_26a = 'checked';
    }else{
        $checked_26a = '';
    }

    if ($kunci->kunci_26 == 'B') {
        $checked_26b = 'checked';
    }else{
        $checked_26b = '';
    }

    if ($kunci->kunci_26 == 'C') {
        $checked_26c = 'checked';
    }else{
        $checked_26c = '';
    }

    if ($kunci->kunci_26 == 'D') {
        $checked_26d = 'checked';
    }else{
        $checked_26d = '';
    }

    if ($kunci->kunci_26 == 'E') {
        $checked_26e = 'checked';
    }else{
        $checked_26e = '';
    }

    if ($kunci->kunci_27 == 'A') {
        $checked_27a = 'checked';
    }else{
        $checked_27a = '';
    }

    if ($kunci->kunci_27 == 'B') {
        $checked_27b = 'checked';
    }else{
        $checked_27b = '';
    }

    if ($kunci->kunci_27 == 'C') {
        $checked_27c = 'checked';
    }else{
        $checked_27c = '';
    }

    if ($kunci->kunci_27 == 'D') {
        $checked_27d = 'checked';
    }else{
        $checked_27d = '';
    }

    if ($kunci->kunci_27 == 'E') {
        $checked_27e = 'checked';
    }else{
        $checked_27e = '';
    }

    if ($kunci->kunci_28 == 'A') {
        $checked_28a = 'checked';
    }else{
        $checked_28a = '';
    }

    if ($kunci->kunci_28 == 'B') {
        $checked_28b = 'checked';
    }else{
        $checked_28b = '';
    }

    if ($kunci->kunci_28 == 'C') {
        $checked_28c = 'checked';
    }else{
        $checked_28c = '';
    }

    if ($kunci->kunci_28 == 'D') {
        $checked_28d = 'checked';
    }else{
        $checked_28d = '';
    }

    if ($kunci->kunci_28 == 'E') {
        $checked_28e = 'checked';
    }else{
        $checked_28e = '';
    }

    if ($kunci->kunci_29 == 'A') {
        $checked_29a = 'checked';
    }else{
        $checked_29a = '';
    }

    if ($kunci->kunci_29 == 'B') {
        $checked_29b = 'checked';
    }else{
        $checked_29b = '';
    }

    if ($kunci->kunci_29 == 'C') {
        $checked_29c = 'checked';
    }else{
        $checked_29c = '';
    }

    if ($kunci->kunci_29 == 'D') {
        $checked_29d = 'checked';
    }else{
        $checked_29d = '';
    }

    if ($kunci->kunci_29 == 'E') {
        $checked_29e = 'checked';
    }else{
        $checked_29e = '';
    }

    if ($kunci->kunci_30 == 'A') {
        $checked_30a = 'checked';
    }else{
        $checked_30a = '';
    }

    if ($kunci->kunci_30 == 'B') {
        $checked_30b = 'checked';
    }else{
        $checked_30b = '';
    }

    if ($kunci->kunci_30 == 'C') {
        $checked_30c = 'checked';
    }else{
        $checked_30c = '';
    }

    if ($kunci->kunci_30 == 'D') {
        $checked_30d = 'checked';
    }else{
        $checked_30d = '';
    }

    if ($kunci->kunci_30 == 'E') {
        $checked_30e = 'checked';
    }else{
        $checked_30e = '';
    }


?>
<div class="main-container">
    <div class="pd-ltr-20 xs-pd-20-10">
        <div class="min-height-200px">
            <div class="page-header">
                <div class="row">
                    <div class="col-md-12 col-sm-12">
                        <div class="title">
                            <h4>Edit Kunci Jawaban Post-Test (<?= $kursus->nama_kursus ?>)</h4>
                        </div>
                        <nav aria-label="breadcrumb" role="navigation">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?=base_url('admin/dashboard')?>">Home</a></li>
                                <li class="breadcrumb-item" aria-current="page"><a href="<?=base_url('admin/posttest')?>">Post-Test</a></li>
                                <li class="breadcrumb-item" aria-current="page"><a href="<?=base_url('admin/posttest/soal_posttest/' . $id)?>">Soal Pre-Test</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Edit Kunci Jawaban</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
            <!-- Isi Tabel Kursus -->

            <div class="panel-body">
				<div class="pd-20 card-box mb-30">
					<div class="clearfix mb-30">
						<div class="pull-left">
							<h4 class="text-blue h4">Form Edit Kunci Jawaban Pre-Test (<?= $kursus->nama_kursus ?>)</h4>
						</div>
					</div>
					<?php
                if (isset($error_upload)) {
                        echo '<div class="alert alert-danger alert-dismissible">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>' . $error_upload . '</div>';
                    }
                    echo form_open_multipart('admin/posttest/edit_kunci/' . $kursus->id_kursus);
                    ?>
                    <?php $no=1; $num=0; foreach ($posttest as $key => $value) {
                        if ($value->id_kursus == $id) { $num++;
                    ?>
                        <?php if ($num==1) { ?>
                            <div class="card w-100 mt-3">
                                <div class="card-body">
                                    <div class="soal mb-3" style="color: black;">
                                        <?=$num?>. <?= $value->soal?>
                                    </div>
                                    <?= form_error('kunci_' . $num, '<div class="text-danger small mb-2" style="font-size: 15px;">', '</div>') ?>
                                    <div class="jawaban ml-4">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="A" <?= $checked_1a ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                A. <?= $value->jawaban_a?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="B" <?= $checked_1b ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                B. <?= $value->jawaban_b?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="C" <?= $checked_1c ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                C. <?= $value->jawaban_c?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="D" <?= $checked_1d ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                D. <?= $value->jawaban_d?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="E" <?= $checked_1e ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                E. <?= $value->jawaban_e?>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                        
                        <?php if ($num==2) { ?>
                            <div class="card w-100 mt-3">
                                <div class="card-body">
                                    <div class="soal mb-3" style="color: black;">
                                        <?=$num?>. <?= $value->soal?>
                                    </div>
                                    <?= form_error('kunci_' . $num, '<div class="text-danger small mb-2" style="font-size: 15px;">', '</div>') ?>
                                    <div class="jawaban ml-4">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="A" <?= $checked_2a ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                A. <?= $value->jawaban_a?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="B" <?= $checked_2b ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                B. <?= $value->jawaban_b?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="C" <?= $checked_2c ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                C. <?= $value->jawaban_c?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="D" <?= $checked_2d ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                D. <?= $value->jawaban_d?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="E" <?= $checked_2e ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                E. <?= $value->jawaban_e?>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                        
                        <?php if ($num==3) { ?>
                            <div class="card w-100 mt-3">
                                <div class="card-body">
                                    <div class="soal mb-3" style="color: black;">
                                        <?=$num?>. <?= $value->soal?>
                                    </div>
                                    <?= form_error('kunci_' . $num, '<div class="text-danger small mb-2" style="font-size: 15px;">', '</div>') ?>
                                    <div class="jawaban ml-4">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="A" <?= $checked_3a ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                A. <?= $value->jawaban_a?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="B" <?= $checked_3b ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                B. <?= $value->jawaban_b?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="C" <?= $checked_3c ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                C. <?= $value->jawaban_c?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="D" <?= $checked_3d ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                D. <?= $value->jawaban_d?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="E" <?= $checked_3e ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                E. <?= $value->jawaban_e?>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                        
                        <?php if ($num==4) { ?>
                            <div class="card w-100 mt-3">
                                <div class="card-body">
                                    <div class="soal mb-3" style="color: black;">
                                        <?=$num?>. <?= $value->soal?>
                                    </div>
                                    <?= form_error('kunci_' . $num, '<div class="text-danger small mb-2" style="font-size: 15px;">', '</div>') ?>
                                    <div class="jawaban ml-4">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="A" <?= $checked_4a ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                A. <?= $value->jawaban_a?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="B" <?= $checked_4b ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                B. <?= $value->jawaban_b?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="C" <?= $checked_4c ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                C. <?= $value->jawaban_c?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="D" <?= $checked_4d ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                D. <?= $value->jawaban_d?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="E" <?= $checked_4e ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                E. <?= $value->jawaban_e?>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                        
                        <?php if ($num==5) { ?>
                            <div class="card w-100 mt-3">
                                <div class="card-body">
                                    <div class="soal mb-3" style="color: black;">
                                        <?=$num?>. <?= $value->soal?>
                                    </div>
                                    <?= form_error('kunci_' . $num, '<div class="text-danger small mb-2" style="font-size: 15px;">', '</div>') ?>
                                    <div class="jawaban ml-4">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="A" <?= $checked_5a ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                A. <?= $value->jawaban_a?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="B" <?= $checked_5b ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                B. <?= $value->jawaban_b?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="C" <?= $checked_5c ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                C. <?= $value->jawaban_c?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="D" <?= $checked_5d ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                D. <?= $value->jawaban_d?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="E" <?= $checked_5e ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                E. <?= $value->jawaban_e?>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                        
                        <?php if ($num==6) { ?>
                            <div class="card w-100 mt-3">
                                <div class="card-body">
                                    <div class="soal mb-3" style="color: black;">
                                        <?=$num?>. <?= $value->soal?>
                                    </div>
                                    <?= form_error('kunci_' . $num, '<div class="text-danger small mb-2" style="font-size: 15px;">', '</div>') ?>
                                    <div class="jawaban ml-4">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="A" <?= $checked_6a ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                A. <?= $value->jawaban_a?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="B" <?= $checked_6b ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                B. <?= $value->jawaban_b?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="C" <?= $checked_6c ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                C. <?= $value->jawaban_c?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="D" <?= $checked_6d ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                D. <?= $value->jawaban_d?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="E" <?= $checked_6e ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                E. <?= $value->jawaban_e?>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                        
                        <?php if ($num==7) { ?>
                            <div class="card w-100 mt-3">
                                <div class="card-body">
                                    <div class="soal mb-3" style="color: black;">
                                        <?=$num?>. <?= $value->soal?>
                                    </div>
                                    <?= form_error('kunci_' . $num, '<div class="text-danger small mb-2" style="font-size: 15px;">', '</div>') ?>
                                    <div class="jawaban ml-4">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="A" <?= $checked_7a ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                A. <?= $value->jawaban_a?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="B" <?= $checked_7b ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                B. <?= $value->jawaban_b?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="C" <?= $checked_7c ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                C. <?= $value->jawaban_c?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="D" <?= $checked_7d ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                D. <?= $value->jawaban_d?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="E" <?= $checked_7e ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                E. <?= $value->jawaban_e?>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                        
                        <?php if ($num==8) { ?>
                            <div class="card w-100 mt-3">
                                <div class="card-body">
                                    <div class="soal mb-3" style="color: black;">
                                        <?=$num?>. <?= $value->soal?>
                                    </div>
                                    <?= form_error('kunci_' . $num, '<div class="text-danger small mb-2" style="font-size: 15px;">', '</div>') ?>
                                    <div class="jawaban ml-4">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="A" <?= $checked_8a ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                A. <?= $value->jawaban_a?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="B" <?= $checked_8b ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                B. <?= $value->jawaban_b?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="C" <?= $checked_8c ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                C. <?= $value->jawaban_c?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="D" <?= $checked_8d ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                D. <?= $value->jawaban_d?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="E" <?= $checked_8e ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                E. <?= $value->jawaban_e?>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                        
                        <?php if ($num==9) { ?>
                            <div class="card w-100 mt-3">
                                <div class="card-body">
                                    <div class="soal mb-3" style="color: black;">
                                        <?=$num?>. <?= $value->soal?>
                                    </div>
                                    <?= form_error('kunci_' . $num, '<div class="text-danger small mb-2" style="font-size: 15px;">', '</div>') ?>
                                    <div class="jawaban ml-4">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="A" <?= $checked_9a ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                A. <?= $value->jawaban_a?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="B" <?= $checked_9b ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                B. <?= $value->jawaban_b?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="C" <?= $checked_9c ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                C. <?= $value->jawaban_c?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="D" <?= $checked_9d ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                D. <?= $value->jawaban_d?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="E" <?= $checked_9e ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                E. <?= $value->jawaban_e?>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                        
                        <?php if ($num==10) { ?>
                            <div class="card w-100 mt-3">
                                <div class="card-body">
                                    <div class="soal mb-3" style="color: black;">
                                        <?=$num?>. <?= $value->soal?>
                                    </div>
                                    <?= form_error('kunci_' . $num, '<div class="text-danger small mb-2" style="font-size: 15px;">', '</div>') ?>
                                    <div class="jawaban ml-4">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="A" <?= $checked_10a ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                A. <?= $value->jawaban_a?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="B" <?= $checked_10b ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                B. <?= $value->jawaban_b?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="C" <?= $checked_10c ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                C. <?= $value->jawaban_c?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="D" <?= $checked_10d ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                D. <?= $value->jawaban_d?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="E" <?= $checked_10e ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                E. <?= $value->jawaban_e?>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>




                        <?php if ($num==11) { ?>
                            <div class="card w-100 mt-3">
                                <div class="card-body">
                                    <div class="soal mb-3" style="color: black;">
                                        <?=$num?>. <?= $value->soal?>
                                    </div>
                                    <?= form_error('kunci_' . $num, '<div class="text-danger small mb-2" style="font-size: 15px;">', '</div>') ?>
                                    <div class="jawaban ml-4">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="A" <?= $checked_11a ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                A. <?= $value->jawaban_a?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="B" <?= $checked_11b ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                B. <?= $value->jawaban_b?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="C" <?= $checked_11c ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                C. <?= $value->jawaban_c?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="D" <?= $checked_11d ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                D. <?= $value->jawaban_d?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="E" <?= $checked_11e ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                E. <?= $value->jawaban_e?>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                        
                        <?php if ($num==12) { ?>
                            <div class="card w-100 mt-3">
                                <div class="card-body">
                                    <div class="soal mb-3" style="color: black;">
                                        <?=$num?>. <?= $value->soal?>
                                    </div>
                                    <?= form_error('kunci_' . $num, '<div class="text-danger small mb-2" style="font-size: 15px;">', '</div>') ?>
                                    <div class="jawaban ml-4">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="A" <?= $checked_12a ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                A. <?= $value->jawaban_a?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="B" <?= $checked_12b ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                B. <?= $value->jawaban_b?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="C" <?= $checked_12c ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                C. <?= $value->jawaban_c?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="D" <?= $checked_12d ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                D. <?= $value->jawaban_d?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="E" <?= $checked_12e ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                E. <?= $value->jawaban_e?>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                        
                        <?php if ($num==13) { ?>
                            <div class="card w-100 mt-3">
                                <div class="card-body">
                                    <div class="soal mb-3" style="color: black;">
                                        <?=$num?>. <?= $value->soal?>
                                    </div>
                                    <?= form_error('kunci_' . $num, '<div class="text-danger small mb-2" style="font-size: 15px;">', '</div>') ?>
                                    <div class="jawaban ml-4">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="A" <?= $checked_13a ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                A. <?= $value->jawaban_a?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="B" <?= $checked_13b ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                B. <?= $value->jawaban_b?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="C" <?= $checked_13c ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                C. <?= $value->jawaban_c?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="D" <?= $checked_13d ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                D. <?= $value->jawaban_d?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="E" <?= $checked_13e ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                E. <?= $value->jawaban_e?>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                        
                        <?php if ($num==14) { ?>
                            <div class="card w-100 mt-3">
                                <div class="card-body">
                                    <div class="soal mb-3" style="color: black;">
                                        <?=$num?>. <?= $value->soal?>
                                    </div>
                                    <?= form_error('kunci_' . $num, '<div class="text-danger small mb-2" style="font-size: 15px;">', '</div>') ?>
                                    <div class="jawaban ml-4">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="A" <?= $checked_14a ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                A. <?= $value->jawaban_a?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="B" <?= $checked_14b ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                B. <?= $value->jawaban_b?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="C" <?= $checked_14c ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                C. <?= $value->jawaban_c?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="D" <?= $checked_14d ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                D. <?= $value->jawaban_d?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="E" <?= $checked_14e ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                E. <?= $value->jawaban_e?>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                        
                        <?php if ($num==15) { ?>
                            <div class="card w-100 mt-3">
                                <div class="card-body">
                                    <div class="soal mb-3" style="color: black;">
                                        <?=$num?>. <?= $value->soal?>
                                    </div>
                                    <?= form_error('kunci_' . $num, '<div class="text-danger small mb-2" style="font-size: 15px;">', '</div>') ?>
                                    <div class="jawaban ml-4">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="A" <?= $checked_15a ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                A. <?= $value->jawaban_a?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="B" <?= $checked_15b ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                B. <?= $value->jawaban_b?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="C" <?= $checked_15c ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                C. <?= $value->jawaban_c?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="D" <?= $checked_15d ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                D. <?= $value->jawaban_d?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="E" <?= $checked_15e ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                E. <?= $value->jawaban_e?>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                        
                        <?php if ($num==16) { ?>
                            <div class="card w-100 mt-3">
                                <div class="card-body">
                                    <div class="soal mb-3" style="color: black;">
                                        <?=$num?>. <?= $value->soal?>
                                    </div>
                                    <?= form_error('kunci_' . $num, '<div class="text-danger small mb-2" style="font-size: 15px;">', '</div>') ?>
                                    <div class="jawaban ml-4">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="A" <?= $checked_16a ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                A. <?= $value->jawaban_a?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="B" <?= $checked_16b ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                B. <?= $value->jawaban_b?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="C" <?= $checked_16c ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                C. <?= $value->jawaban_c?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="D" <?= $checked_16d ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                D. <?= $value->jawaban_d?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="E" <?= $checked_16e ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                E. <?= $value->jawaban_e?>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                        
                        <?php if ($num==17) { ?>
                            <div class="card w-100 mt-3">
                                <div class="card-body">
                                    <div class="soal mb-3" style="color: black;">
                                        <?=$num?>. <?= $value->soal?>
                                    </div>
                                    <?= form_error('kunci_' . $num, '<div class="text-danger small mb-2" style="font-size: 15px;">', '</div>') ?>
                                    <div class="jawaban ml-4">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="A" <?= $checked_17a ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                A. <?= $value->jawaban_a?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="B" <?= $checked_17b ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                B. <?= $value->jawaban_b?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="C" <?= $checked_17c ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                C. <?= $value->jawaban_c?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="D" <?= $checked_17d ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                D. <?= $value->jawaban_d?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="E" <?= $checked_17e ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                E. <?= $value->jawaban_e?>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                        
                        <?php if ($num==18) { ?>
                            <div class="card w-100 mt-3">
                                <div class="card-body">
                                    <div class="soal mb-3" style="color: black;">
                                        <?=$num?>. <?= $value->soal?>
                                    </div>
                                    <?= form_error('kunci_' . $num, '<div class="text-danger small mb-2" style="font-size: 15px;">', '</div>') ?>
                                    <div class="jawaban ml-4">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="A" <?= $checked_18a ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                A. <?= $value->jawaban_a?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="B" <?= $checked_18b ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                B. <?= $value->jawaban_b?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="C" <?= $checked_18c ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                C. <?= $value->jawaban_c?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="D" <?= $checked_18d ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                D. <?= $value->jawaban_d?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="E" <?= $checked_18e ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                E. <?= $value->jawaban_e?>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                        
                        <?php if ($num==19) { ?>
                            <div class="card w-100 mt-3">
                                <div class="card-body">
                                    <div class="soal mb-3" style="color: black;">
                                        <?=$num?>. <?= $value->soal?>
                                    </div>
                                    <?= form_error('kunci_' . $num, '<div class="text-danger small mb-2" style="font-size: 15px;">', '</div>') ?>
                                    <div class="jawaban ml-4">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="A" <?= $checked_19a ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                A. <?= $value->jawaban_a?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="B" <?= $checked_19b ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                B. <?= $value->jawaban_b?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="C" <?= $checked_19c ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                C. <?= $value->jawaban_c?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="D" <?= $checked_19d ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                D. <?= $value->jawaban_d?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="E" <?= $checked_19e ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                E. <?= $value->jawaban_e?>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                        
                        <?php if ($num==20) { ?>
                            <div class="card w-100 mt-3">
                                <div class="card-body">
                                    <div class="soal mb-3" style="color: black;">
                                        <?=$num?>. <?= $value->soal?>
                                    </div>
                                    <?= form_error('kunci_' . $num, '<div class="text-danger small mb-2" style="font-size: 15px;">', '</div>') ?>
                                    <div class="jawaban ml-4">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="A" <?= $checked_20a ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                A. <?= $value->jawaban_a?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="B" <?= $checked_20b ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                B. <?= $value->jawaban_b?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="C" <?= $checked_20c ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                C. <?= $value->jawaban_c?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="D" <?= $checked_20d ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                D. <?= $value->jawaban_d?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="E" <?= $checked_20e ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                E. <?= $value->jawaban_e?>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>



                        <?php if ($num==21) { ?>
                            <div class="card w-100 mt-3">
                                <div class="card-body">
                                    <div class="soal mb-3" style="color: black;">
                                        <?=$num?>. <?= $value->soal?>
                                    </div>
                                    <?= form_error('kunci_' . $num, '<div class="text-danger small mb-2" style="font-size: 15px;">', '</div>') ?>
                                    <div class="jawaban ml-4">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="A" <?= $checked_21a ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                A. <?= $value->jawaban_a?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="B" <?= $checked_21b ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                B. <?= $value->jawaban_b?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="C" <?= $checked_21c ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                C. <?= $value->jawaban_c?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="D" <?= $checked_21d ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                D. <?= $value->jawaban_d?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="E" <?= $checked_21e ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                E. <?= $value->jawaban_e?>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                        
                        <?php if ($num==22) { ?>
                            <div class="card w-100 mt-3">
                                <div class="card-body">
                                    <div class="soal mb-3" style="color: black;">
                                        <?=$num?>. <?= $value->soal?>
                                    </div>
                                    <?= form_error('kunci_' . $num, '<div class="text-danger small mb-2" style="font-size: 15px;">', '</div>') ?>
                                    <div class="jawaban ml-4">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="A" <?= $checked_22a ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                A. <?= $value->jawaban_a?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="B" <?= $checked_22b ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                B. <?= $value->jawaban_b?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="C" <?= $checked_22c ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                C. <?= $value->jawaban_c?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="D" <?= $checked_22d ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                D. <?= $value->jawaban_d?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="E" <?= $checked_22e ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                E. <?= $value->jawaban_e?>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                        
                        <?php if ($num==23) { ?>
                            <div class="card w-100 mt-3">
                                <div class="card-body">
                                    <div class="soal mb-3" style="color: black;">
                                        <?=$num?>. <?= $value->soal?>
                                    </div>
                                    <?= form_error('kunci_' . $num, '<div class="text-danger small mb-2" style="font-size: 15px;">', '</div>') ?>
                                    <div class="jawaban ml-4">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="A" <?= $checked_23a ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                A. <?= $value->jawaban_a?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="B" <?= $checked_23b ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                B. <?= $value->jawaban_b?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="C" <?= $checked_23c ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                C. <?= $value->jawaban_c?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="D" <?= $checked_23d ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                D. <?= $value->jawaban_d?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="E" <?= $checked_23e ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                E. <?= $value->jawaban_e?>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                        
                        <?php if ($num==24) { ?>
                            <div class="card w-100 mt-3">
                                <div class="card-body">
                                    <div class="soal mb-3" style="color: black;">
                                        <?=$num?>. <?= $value->soal?>
                                    </div>
                                    <?= form_error('kunci_' . $num, '<div class="text-danger small mb-2" style="font-size: 15px;">', '</div>') ?>
                                    <div class="jawaban ml-4">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="A" <?= $checked_24a ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                A. <?= $value->jawaban_a?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="B" <?= $checked_24b ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                B. <?= $value->jawaban_b?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="C" <?= $checked_24c ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                C. <?= $value->jawaban_c?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="D" <?= $checked_24d ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                D. <?= $value->jawaban_d?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="E" <?= $checked_24e ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                E. <?= $value->jawaban_e?>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                        
                        <?php if ($num==25) { ?>
                            <div class="card w-100 mt-3">
                                <div class="card-body">
                                    <div class="soal mb-3" style="color: black;">
                                        <?=$num?>. <?= $value->soal?>
                                    </div>
                                    <?= form_error('kunci_' . $num, '<div class="text-danger small mb-2" style="font-size: 15px;">', '</div>') ?>
                                    <div class="jawaban ml-4">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="A" <?= $checked_25a ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                A. <?= $value->jawaban_a?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="B" <?= $checked_25b ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                B. <?= $value->jawaban_b?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="C" <?= $checked_25c ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                C. <?= $value->jawaban_c?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="D" <?= $checked_25d ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                D. <?= $value->jawaban_d?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="E" <?= $checked_25e ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                E. <?= $value->jawaban_e?>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                        
                        <?php if ($num==26) { ?>
                            <div class="card w-100 mt-3">
                                <div class="card-body">
                                    <div class="soal mb-3" style="color: black;">
                                        <?=$num?>. <?= $value->soal?>
                                    </div>
                                    <?= form_error('kunci_' . $num, '<div class="text-danger small mb-2" style="font-size: 15px;">', '</div>') ?>
                                    <div class="jawaban ml-4">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="A" <?= $checked_26a ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                A. <?= $value->jawaban_a?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="B" <?= $checked_26b ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                B. <?= $value->jawaban_b?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="C" <?= $checked_26c ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                C. <?= $value->jawaban_c?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="D" <?= $checked_26d ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                D. <?= $value->jawaban_d?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="E" <?= $checked_26e ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                E. <?= $value->jawaban_e?>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                        
                        <?php if ($num==27) { ?>
                            <div class="card w-100 mt-3">
                                <div class="card-body">
                                    <div class="soal mb-3" style="color: black;">
                                        <?=$num?>. <?= $value->soal?>
                                    </div>
                                    <?= form_error('kunci_' . $num, '<div class="text-danger small mb-2" style="font-size: 15px;">', '</div>') ?>
                                    <div class="jawaban ml-4">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="A" <?= $checked_27a ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                A. <?= $value->jawaban_a?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="B" <?= $checked_27b ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                B. <?= $value->jawaban_b?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="C" <?= $checked_27c ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                C. <?= $value->jawaban_c?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="D" <?= $checked_27d ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                D. <?= $value->jawaban_d?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="E" <?= $checked_27e ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                E. <?= $value->jawaban_e?>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                        
                        <?php if ($num==28) { ?>
                            <div class="card w-100 mt-3">
                                <div class="card-body">
                                    <div class="soal mb-3" style="color: black;">
                                        <?=$num?>. <?= $value->soal?>
                                    </div>
                                    <?= form_error('kunci_' . $num, '<div class="text-danger small mb-2" style="font-size: 15px;">', '</div>') ?>
                                    <div class="jawaban ml-4">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="A" <?= $checked_28a ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                A. <?= $value->jawaban_a?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="B" <?= $checked_28b ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                B. <?= $value->jawaban_b?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="C" <?= $checked_28c ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                C. <?= $value->jawaban_c?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="D" <?= $checked_28d ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                D. <?= $value->jawaban_d?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="E" <?= $checked_28e ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                E. <?= $value->jawaban_e?>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                        
                        <?php if ($num==29) { ?>
                            <div class="card w-100 mt-3">
                                <div class="card-body">
                                    <div class="soal mb-3" style="color: black;">
                                        <?=$num?>. <?= $value->soal?>
                                    </div>
                                    <?= form_error('kunci_' . $num, '<div class="text-danger small mb-2" style="font-size: 15px;">', '</div>') ?>
                                    <div class="jawaban ml-4">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="A" <?= $checked_29a ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                A. <?= $value->jawaban_a?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="B" <?= $checked_29b ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                B. <?= $value->jawaban_b?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="C" <?= $checked_29c ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                C. <?= $value->jawaban_c?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="D" <?= $checked_29d ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                D. <?= $value->jawaban_d?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="E" <?= $checked_29e ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                E. <?= $value->jawaban_e?>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                        
                        <?php if ($num==30) { ?>
                            <div class="card w-100 mt-3">
                                <div class="card-body">
                                    <div class="soal mb-3" style="color: black;">
                                        <?=$num?>. <?= $value->soal?>
                                    </div>
                                    <?= form_error('kunci_' . $num, '<div class="text-danger small mb-2" style="font-size: 15px;">', '</div>') ?>
                                    <div class="jawaban ml-4">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="A" <?= $checked_30a ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                A. <?= $value->jawaban_a?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="B" <?= $checked_30b ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                B. <?= $value->jawaban_b?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="C" <?= $checked_30c ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                C. <?= $value->jawaban_c?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="D" <?= $checked_30d ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                D. <?= $value->jawaban_d?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="E" <?= $checked_30e ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                E. <?= $value->jawaban_e?>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                        

                    <?php  }} ?>
                    <div class="form-group text-center mt-3">
                        <button type="reset" class="btn btn-danger mr-2">Bersihkan</button>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>

                    <?php echo form_close(); ?>
        </div>
        </div>

        