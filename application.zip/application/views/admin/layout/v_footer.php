			<div class="footer-wrap pd-20 mb-20 card-box">
				Dodi Devrian - Teknik Informatika
			</div>
		</div>
	</div>
	<!-- js -->
	<script src="<?= base_url() ?>assets/backend/vendors/scripts/core.js"></script>
	<script src="<?= base_url() ?>assets/backend/vendors/scripts/script.min.js"></script>
	<script src="<?= base_url() ?>assets/backend/vendors/scripts/process.js"></script>
	<script src="<?= base_url() ?>assets/backend/vendors/scripts/layout-settings.js"></script>
	
	<script src="<?= base_url() ?>assets/backend/src/plugins/datatables/js/jquery.dataTables.min.js"></script>
	<script src="<?= base_url() ?>assets/backend/src/plugins/datatables/js/dataTables.bootstrap4.min.js"></script>
	<script src="<?= base_url() ?>assets/backend/src/plugins/datatables/js/dataTables.responsive.min.js"></script>
	<script src="<?= base_url() ?>assets/backend/src/plugins/datatables/js/responsive.bootstrap4.min.js"></script>
	<!-- buttons for Export datatable -->
	<script src="<?= base_url() ?>assets/backend/src/plugins/datatables/js/dataTables.buttons.min.js"></script>
	<script src="<?= base_url() ?>assets/backend/src/plugins/datatables/js/buttons.bootstrap4.min.js"></script>
	<script src="<?= base_url() ?>assets/backend/src/plugins/datatables/js/buttons.print.min.js"></script>
	<script src="<?= base_url() ?>assets/backend/src/plugins/datatables/js/buttons.html5.min.js"></script>
	<script src="<?= base_url() ?>assets/backend/src/plugins/datatables/js/buttons.flash.min.js"></script>
	<script src="<?= base_url() ?>assets/backend/src/plugins/datatables/js/pdfmake.min.js"></script>
	<script src="<?= base_url() ?>assets/backend/src/plugins/datatables/js/vfs_fonts.js"></script>
	<!-- Datatable Setting js -->
	<script src="<?= base_url() ?>assets/backend/vendors/scripts/datatable-setting.js"></script>

	<!-- fancybox Popup Js -->
	<script src="<?= base_url() ?>assets/backend/src/plugins/fancybox/dist/jquery.fancybox.js"></script>

	<script src="<?= base_url() ?>assets/backend/src/plugins/switchery/switchery.min.js"></script>
	<!-- bootstrap-tagsinput js -->
	<script src="<?= base_url() ?>assets/backend/src/plugins/bootstrap-tagsinput/bootstrap-tagsinput.js"></script>
	<!-- bootstrap-touchspin js -->
	<script src="<?= base_url() ?>assets/backend/src/plugins/bootstrap-touchspin/jquery.bootstrap-touchspin.js"></script>
	<script src="<?= base_url() ?>assets/backend/vendors/scripts/advanced-components.js"></script>

	

</body>
</html>