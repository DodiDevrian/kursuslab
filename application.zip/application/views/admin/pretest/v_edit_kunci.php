<?php $sumsoal=1; $sum=1; foreach ($pretest as $key => $value) {
            if ($value->id_materi == $id) {
                $sumsoal += $sum;
            }} ?>

<?php 
    if ($kunci->kunci_1 == 'A') {
        $checked_1a = 'checked';
    }else{
        $checked_1a = '';
    }

    if ($kunci->kunci_1 == 'B') {
        $checked_1b = 'checked';
    }else{
        $checked_1b = '';
    }

    if ($kunci->kunci_1 == 'C') {
        $checked_1c = 'checked';
    }else{
        $checked_1c = '';
    }

    if ($kunci->kunci_1 == 'D') {
        $checked_1d = 'checked';
    }else{
        $checked_1d = '';
    }

    if ($kunci->kunci_1 == 'E') {
        $checked_1e = 'checked';
    }else{
        $checked_1e = '';
    }


    if ($kunci->kunci_2 == 'A') {
        $checked_2a = 'checked';
    }else{
        $checked_2a = '';
    }

    if ($kunci->kunci_2 == 'B') {
        $checked_2b = 'checked';
    }else{
        $checked_2b = '';
    }

    if ($kunci->kunci_2 == 'C') {
        $checked_2c = 'checked';
    }else{
        $checked_2c = '';
    }

    if ($kunci->kunci_2 == 'D') {
        $checked_2d = 'checked';
    }else{
        $checked_2d = '';
    }

    if ($kunci->kunci_2 == 'E') {
        $checked_2e = 'checked';
    }else{
        $checked_2e = '';
    }


    if ($kunci->kunci_3 == 'A') {
        $checked_3a = 'checked';
    }else{
        $checked_3a = '';
    }

    if ($kunci->kunci_3 == 'B') {
        $checked_3b = 'checked';
    }else{
        $checked_3b = '';
    }

    if ($kunci->kunci_3 == 'C') {
        $checked_3c = 'checked';
    }else{
        $checked_3c = '';
    }

    if ($kunci->kunci_3 == 'D') {
        $checked_3d = 'checked';
    }else{
        $checked_3d = '';
    }

    if ($kunci->kunci_3 == 'E') {
        $checked_3e = 'checked';
    }else{
        $checked_3e = '';
    }

    if ($kunci->kunci_4 == 'A') {
        $checked_4a = 'checked';
    }else{
        $checked_4a = '';
    }

    if ($kunci->kunci_4 == 'B') {
        $checked_4b = 'checked';
    }else{
        $checked_4b = '';
    }

    if ($kunci->kunci_4 == 'C') {
        $checked_4c = 'checked';
    }else{
        $checked_4c = '';
    }

    if ($kunci->kunci_4 == 'D') {
        $checked_4d = 'checked';
    }else{
        $checked_4d = '';
    }

    if ($kunci->kunci_4 == 'E') {
        $checked_4e = 'checked';
    }else{
        $checked_4e = '';
    }

    if ($kunci->kunci_5 == 'A') {
        $checked_5a = 'checked';
    }else{
        $checked_5a = '';
    }

    if ($kunci->kunci_5 == 'B') {
        $checked_5b = 'checked';
    }else{
        $checked_5b = '';
    }

    if ($kunci->kunci_5 == 'C') {
        $checked_5c = 'checked';
    }else{
        $checked_5c = '';
    }

    if ($kunci->kunci_5 == 'D') {
        $checked_5d = 'checked';
    }else{
        $checked_5d = '';
    }

    if ($kunci->kunci_5 == 'E') {
        $checked_5e = 'checked';
    }else{
        $checked_5e = '';
    }


    if ($kunci->kunci_6 == 'A') {
        $checked_6a = 'checked';
    }else{
        $checked_6a = '';
    }

    if ($kunci->kunci_6 == 'B') {
        $checked_6b = 'checked';
    }else{
        $checked_6b = '';
    }

    if ($kunci->kunci_6 == 'C') {
        $checked_6c = 'checked';
    }else{
        $checked_6c = '';
    }

    if ($kunci->kunci_6 == 'D') {
        $checked_6d = 'checked';
    }else{
        $checked_6d = '';
    }

    if ($kunci->kunci_6 == 'E') {
        $checked_6e = 'checked';
    }else{
        $checked_6e = '';
    }

    if ($kunci->kunci_7 == 'A') {
        $checked_7a = 'checked';
    }else{
        $checked_7a = '';
    }

    if ($kunci->kunci_7 == 'B') {
        $checked_7b = 'checked';
    }else{
        $checked_7b = '';
    }

    if ($kunci->kunci_7 == 'C') {
        $checked_7c = 'checked';
    }else{
        $checked_7c = '';
    }

    if ($kunci->kunci_7 == 'D') {
        $checked_7d = 'checked';
    }else{
        $checked_7d = '';
    }

    if ($kunci->kunci_7 == 'E') {
        $checked_7e = 'checked';
    }else{
        $checked_7e = '';
    }

    if ($kunci->kunci_8 == 'A') {
        $checked_8a = 'checked';
    }else{
        $checked_8a = '';
    }

    if ($kunci->kunci_8 == 'B') {
        $checked_8b = 'checked';
    }else{
        $checked_8b = '';
    }

    if ($kunci->kunci_8 == 'C') {
        $checked_8c = 'checked';
    }else{
        $checked_8c = '';
    }

    if ($kunci->kunci_8 == 'D') {
        $checked_8d = 'checked';
    }else{
        $checked_8d = '';
    }

    if ($kunci->kunci_8 == 'E') {
        $checked_8e = 'checked';
    }else{
        $checked_8e = '';
    }

    if ($kunci->kunci_9 == 'A') {
        $checked_9a = 'checked';
    }else{
        $checked_9a = '';
    }

    if ($kunci->kunci_9 == 'B') {
        $checked_9b = 'checked';
    }else{
        $checked_9b = '';
    }

    if ($kunci->kunci_9 == 'C') {
        $checked_9c = 'checked';
    }else{
        $checked_9c = '';
    }

    if ($kunci->kunci_9 == 'D') {
        $checked_9d = 'checked';
    }else{
        $checked_9d = '';
    }

    if ($kunci->kunci_9 == 'E') {
        $checked_9e = 'checked';
    }else{
        $checked_9e = '';
    }

    if ($kunci->kunci_10 == 'A') {
        $checked_10a = 'checked';
    }else{
        $checked_10a = '';
    }

    if ($kunci->kunci_10 == 'B') {
        $checked_10b = 'checked';
    }else{
        $checked_10b = '';
    }

    if ($kunci->kunci_10 == 'C') {
        $checked_10c = 'checked';
    }else{
        $checked_10c = '';
    }

    if ($kunci->kunci_10 == 'D') {
        $checked_10d = 'checked';
    }else{
        $checked_10d = '';
    }

    if ($kunci->kunci_10 == 'E') {
        $checked_10e = 'checked';
    }else{
        $checked_10e = '';
    }


?>
<div class="main-container">
    <div class="pd-ltr-20 xs-pd-20-10">
        <div class="min-height-200px">
            <div class="page-header">
                <div class="row">
                    <div class="col-md-12 col-sm-12">
                        <div class="title">
                            <h4>Edit Kunci Jawaban Pre-Test (<?= $materi->nama_materi ?>)</h4>
                        </div>
                        <nav aria-label="breadcrumb" role="navigation">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?=base_url('admin/dashboard')?>">Home</a></li>
                                <li class="breadcrumb-item" aria-current="page"><a href="<?=base_url('admin/pretest')?>">Pretest</a></li>
                                <li class="breadcrumb-item" aria-current="page"><a href="<?=base_url('admin/pretest/list_soal/' . $id)?>">Soal Pre-Test</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Edit Kunci Jawaban</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
            <!-- Isi Tabel Kursus -->

            <div class="panel-body">
				<div class="pd-20 card-box mb-30">
					<div class="clearfix mb-30">
						<div class="pull-left">
							<h4 class="text-blue h4">Form Edit Kunci Jawaban Pre-Test (<?= $materi->nama_materi ?>)</h4>
						</div>
					</div>
					<?php
                if (isset($error_upload)) {
                        echo '<div class="alert alert-danger alert-dismissible">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>' . $error_upload . '</div>';
                    }
                    echo form_open_multipart('admin/pretest/edit_kunci/' . $materi->id_materi);
                    ?>
                    <?php $no=1; $num=0; foreach ($pretest as $key => $value) {
                        if ($value->id_materi == $id) { $num++;
                    ?>
                        <?php if ($num==1) { ?>
                            <div class="card w-100 mt-3">
                                <div class="card-body">
                                    <div class="soal mb-3" style="color: black;">
                                        <?=$no++?>. <?= $value->soal?>
                                    </div>
                                    <?= form_error('kunci_' . $num, '<div class="text-danger small mb-2" style="font-size: 15px;">', '</div>') ?>
                                    <div class="jawaban ml-4">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="A" <?= $checked_1a ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                A. <?= $value->jawaban_a?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="B" <?= $checked_1b ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                B. <?= $value->jawaban_b?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="C" <?= $checked_1c ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                C. <?= $value->jawaban_c?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="D" <?= $checked_1d ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                D. <?= $value->jawaban_d?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="E" <?= $checked_1e ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                E. <?= $value->jawaban_e?>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                        
                        <?php if ($num==2) { ?>
                            <div class="card w-100 mt-3">
                                <div class="card-body">
                                    <div class="soal mb-3" style="color: black;">
                                        <?=$no++?>. <?= $value->soal?>
                                    </div>
                                    <?= form_error('kunci_' . $num, '<div class="text-danger small mb-2" style="font-size: 15px;">', '</div>') ?>
                                    <div class="jawaban ml-4">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="A" <?= $checked_2a ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                A. <?= $value->jawaban_a?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="B" <?= $checked_2b ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                B. <?= $value->jawaban_b?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="C" <?= $checked_2c ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                C. <?= $value->jawaban_c?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="D" <?= $checked_2d ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                D. <?= $value->jawaban_d?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="E" <?= $checked_2e ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                E. <?= $value->jawaban_e?>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                        
                        <?php if ($num==3) { ?>
                            <div class="card w-100 mt-3">
                                <div class="card-body">
                                    <div class="soal mb-3" style="color: black;">
                                        <?=$no++?>. <?= $value->soal?>
                                    </div>
                                    <?= form_error('kunci_' . $num, '<div class="text-danger small mb-2" style="font-size: 15px;">', '</div>') ?>
                                    <div class="jawaban ml-4">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="A" <?= $checked_3a ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                A. <?= $value->jawaban_a?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="B" <?= $checked_3b ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                B. <?= $value->jawaban_b?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="C" <?= $checked_3c ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                C. <?= $value->jawaban_c?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="D" <?= $checked_3d ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                D. <?= $value->jawaban_d?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="E" <?= $checked_3e ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                E. <?= $value->jawaban_e?>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                        
                        <?php if ($num==4) { ?>
                            <div class="card w-100 mt-3">
                                <div class="card-body">
                                    <div class="soal mb-3" style="color: black;">
                                        <?=$no++?>. <?= $value->soal?>
                                    </div>
                                    <?= form_error('kunci_' . $num, '<div class="text-danger small mb-2" style="font-size: 15px;">', '</div>') ?>
                                    <div class="jawaban ml-4">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="A" <?= $checked_4a ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                A. <?= $value->jawaban_a?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="B" <?= $checked_4b ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                B. <?= $value->jawaban_b?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="C" <?= $checked_4c ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                C. <?= $value->jawaban_c?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="D" <?= $checked_4d ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                D. <?= $value->jawaban_d?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="E" <?= $checked_4e ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                E. <?= $value->jawaban_e?>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                        
                        <?php if ($num==5) { ?>
                            <div class="card w-100 mt-3">
                                <div class="card-body">
                                    <div class="soal mb-3" style="color: black;">
                                        <?=$no++?>. <?= $value->soal?>
                                    </div>
                                    <?= form_error('kunci_' . $num, '<div class="text-danger small mb-2" style="font-size: 15px;">', '</div>') ?>
                                    <div class="jawaban ml-4">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="A" <?= $checked_5a ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                A. <?= $value->jawaban_a?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="B" <?= $checked_5b ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                B. <?= $value->jawaban_b?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="C" <?= $checked_5c ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                C. <?= $value->jawaban_c?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="D" <?= $checked_5d ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                D. <?= $value->jawaban_d?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="E" <?= $checked_5e ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                E. <?= $value->jawaban_e?>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                        
                        <?php if ($num==6) { ?>
                            <div class="card w-100 mt-3">
                                <div class="card-body">
                                    <div class="soal mb-3" style="color: black;">
                                        <?=$no++?>. <?= $value->soal?>
                                    </div>
                                    <?= form_error('kunci_' . $num, '<div class="text-danger small mb-2" style="font-size: 15px;">', '</div>') ?>
                                    <div class="jawaban ml-4">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="A" <?= $checked_6a ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                A. <?= $value->jawaban_a?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="B" <?= $checked_6b ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                B. <?= $value->jawaban_b?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="C" <?= $checked_6c ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                C. <?= $value->jawaban_c?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="D" <?= $checked_6d ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                D. <?= $value->jawaban_d?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="E" <?= $checked_6e ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                E. <?= $value->jawaban_e?>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                        
                        <?php if ($num==7) { ?>
                            <div class="card w-100 mt-3">
                                <div class="card-body">
                                    <div class="soal mb-3" style="color: black;">
                                        <?=$no++?>. <?= $value->soal?>
                                    </div>
                                    <?= form_error('kunci_' . $num, '<div class="text-danger small mb-2" style="font-size: 15px;">', '</div>') ?>
                                    <div class="jawaban ml-4">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="A" <?= $checked_7a ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                A. <?= $value->jawaban_a?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="B" <?= $checked_7b ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                B. <?= $value->jawaban_b?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="C" <?= $checked_7c ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                C. <?= $value->jawaban_c?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="D" <?= $checked_7d ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                D. <?= $value->jawaban_d?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="E" <?= $checked_7e ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                E. <?= $value->jawaban_e?>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                        
                        <?php if ($num==8) { ?>
                            <div class="card w-100 mt-3">
                                <div class="card-body">
                                    <div class="soal mb-3" style="color: black;">
                                        <?=$no++?>. <?= $value->soal?>
                                    </div>
                                    <?= form_error('kunci_' . $num, '<div class="text-danger small mb-2" style="font-size: 15px;">', '</div>') ?>
                                    <div class="jawaban ml-4">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="A" <?= $checked_8a ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                A. <?= $value->jawaban_a?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="B" <?= $checked_8b ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                B. <?= $value->jawaban_b?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="C" <?= $checked_8c ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                C. <?= $value->jawaban_c?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="D" <?= $checked_8d ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                D. <?= $value->jawaban_d?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="E" <?= $checked_8e ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                E. <?= $value->jawaban_e?>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                        
                        <?php if ($num==9) { ?>
                            <div class="card w-100 mt-3">
                                <div class="card-body">
                                    <div class="soal mb-3" style="color: black;">
                                        <?=$no++?>. <?= $value->soal?>
                                    </div>
                                    <?= form_error('kunci_' . $num, '<div class="text-danger small mb-2" style="font-size: 15px;">', '</div>') ?>
                                    <div class="jawaban ml-4">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="A" <?= $checked_9a ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                A. <?= $value->jawaban_a?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="B" <?= $checked_9b ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                B. <?= $value->jawaban_b?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="C" <?= $checked_9c ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                C. <?= $value->jawaban_c?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="D" <?= $checked_9d ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                D. <?= $value->jawaban_d?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="E" <?= $checked_9e ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                E. <?= $value->jawaban_e?>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                        
                        <?php if ($num==10) { ?>
                            <div class="card w-100 mt-3">
                                <div class="card-body">
                                    <div class="soal mb-3" style="color: black;">
                                        <?=$no++?>. <?= $value->soal?>
                                    </div>
                                    <?= form_error('kunci_' . $num, '<div class="text-danger small mb-2" style="font-size: 15px;">', '</div>') ?>
                                    <div class="jawaban ml-4">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="A" <?= $checked_10a ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                A. <?= $value->jawaban_a?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="B" <?= $checked_10b ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                B. <?= $value->jawaban_b?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="C" <?= $checked_10c ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                C. <?= $value->jawaban_c?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="D" <?= $checked_10d ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                D. <?= $value->jawaban_d?>
                                            </label>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="kunci_<?= $num ?>" id="exampleRadios1" value="E" <?= $checked_10e ?>>
                                            <label class="form-check-label" for="exampleRadios1" style="color: black;">
                                                E. <?= $value->jawaban_e?>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                        

                    <?php  }} ?>
                    <div class="form-group text-center mt-3">
                        <button type="reset" class="btn btn-danger mr-2">Bersihkan</button>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>

                    <?php echo form_close(); ?>
        </div>
        </div>

        