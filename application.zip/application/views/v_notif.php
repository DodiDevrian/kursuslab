<link rel="stylesheet" type="text/css" href="<?= base_url() ?>assets/frontend/styles/courses.css">
<link rel="stylesheet" type="text/css" href="<?= base_url() ?>assets/frontend/styles/courses_responsive.css">

<div class="home">
    <div class="breadcrumbs_container">
        <div class="container">
            <div class="row">
                <div class="col">
                    <div class="breadcrumbs">
                        <ul>
                            <li><a href="<?= base_url() ?>">Home</a></li>
                            <li>Peringatan</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>			
</div>

<div class="team">
    <div class="container">
        <div class="jumbotron" style="margin-bottom: 100px;">
            <h2 class="text-center mb-3" style="color: red;">Akun anda masih diperiksa!</h2>
            <p class="lead">Untuk saat ini anda tidak dapat menggunakan beberapa fitur penting pada website ini.</p>
            <p class="lead">Tunggu sampai laboran menerima akun anda!</p>
        </div>
    </div>
	